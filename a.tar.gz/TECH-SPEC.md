# 네이버 부동산 크롤링 시스템 기술 사양서

## 프로젝트 개요

네이버 부동산 사이트의 부동산 정보를 자동으로 수집하여 CSV 파일로 저장하는 크롤링 시스템입니다. 강동구 지역을 기준으로 아파트, 상가 등의 매물 정보를 수집합니다.

## 요구사항 분석

### 기능 요구사항

#### FR-001: 부동산 데이터 수집
- 네이버 부동산 검색 결과 페이지에서 복합 단지 정보 수집
- 아파트(APT), 매매(A1), 상가(RETAIL) 타입 지원
- 가격 범위 필터링 (90,000 ~ 110,000만원)
- 지역 코드 기반 필터링 (강동구: 132)

#### FR-002: 데이터 저장
- 수집된 데이터를 CSV 형식으로 저장
- UTF-8 인코딩 지원 (한글 데이터 호환)
- 타임스탬프 정보 포함

#### FR-003: 안정성 보장
- Selenium WebDriver를 통한 JavaScript 렌더링 지원
- 예외 처리 및 오류 로깅
- Headless 브라우저 모드 지원

### 비기능 요구사항

#### NFR-001: 성능
- 단일 실행으로 최대 수십 개의 복합 단지 정보 수집
- 페이지 로딩 시간 3초 이내 완료

#### NFR-002: 호환성
- Python 3.9+ 지원
- Chrome 브라우저 호환
- Windows/macOS/Linux 크로스 플랫폼 지원

#### NFR-003: 유지보수성
- 모듈화된 코드 구조
- 설정 파일 기반 파라미터 관리
- 상세한 주석 및 문서화

## 기술 스택

### 프로그래밍 언어
- Python 3.9+

### 주요 라이브러리
```
# pyproject.toml dependencies
requests>=2.31.0          # HTTP 요청 처리
beautifulsoup4>=4.12.2     # HTML 파싱 (예비용)
pandas>=2.1.3              # 데이터 처리 및 CSV 저장
selenium>=4.15.2           # 웹 브라우저 자동화
webdriver-manager>=4.0.1   # WebDriver 자동 관리
```

### 개발 환경
- 운영체제: Windows/macOS/Linux
- 브라우저: Chrome (WebDriver 자동 설치)
- 패키지 관리: uv (빠른 Python 패키지 매니저)
- 프로젝트 관리: pyproject.toml

## 시스템 아키텍처

### 컴포넌트 구성

#### 1. NaverLandCrawler 클래스
- **역할**: 메인 크롤링 로직 담당
- **주요 메서드**:
  - `__init__()`: 초기화 및 데이터 저장소 설정
  - `setup_driver()`: Selenium WebDriver 설정
  - `crawl_complexes()`: 복합 단지 정보 수집
  - `save_to_csv()`: 데이터 CSV 저장

#### 2. 설정 관리 (config.py)
- **목적**: 크롤링 파라미터 및 설정값 중앙 관리
- **설정 항목**:
  - `CRAWL_DELAY`: 요청 간격 (초)
  - `MAX_RETRIES`: 최대 재시도 횟수
  - `TIMEOUT`: 요청 타임아웃
  - `DEFAULT_PARAMS`: URL 파라미터 기본값

### 데이터 흐름

```
1. 설정 로드 (config.py)
2. WebDriver 초기화
3. 대상 URL 생성 및 접속
4. JavaScript 렌더링 대기 (3초)
5. DOM 요소 탐색 및 데이터 추출
6. 데이터 구조화 및 저장
7. CSV 파일 출력
8. 브라우저 종료
```

## 인터페이스 설계

### 입력 인터페이스

#### URL 파라미터
```python
DEFAULT_PARAMS = {
    'ms': '37.530126,127.123771,15',  # 지도 중심 좌표 및 줌 레벨
    'a': 'APT',                        # 부동산 타입 (아파트)
    'b': 'A1',                         # 거래 타입 (매매)
    'e': 'RETAIL',                     # 추가 타입 (상가)
    'f': '90000',                      # 최소 가격 (만원)
    'g': '110000',                     # 최대 가격 (만원)
    'h': '99',                         # 방 수 (99=전체)
    'i': '132'                         # 지역 코드 (강동구)
}
```

### 출력 인터페이스

#### CSV 파일 구조 (아파트 상세 정보)
```csv
complex_name,address,sale_price,lease_price,exclusive_area,supply_area,build_year,floor_info,maintenance_fee,detail_url,crawl_date,method
"래미안 강동팰리스","서울시 강동구 천호동 123","10억 5,000만원","8억 2,000만원","84.97㎡","104.97㎡","2020","15층","15만원","https://land.naver.com/complexes/123","2024-01-15 14:30:00","detail_page"
"힐스테이트 천호역젠트리스","서울시 강동구 천호동 456","9억 8,000만원","7억 5,000만원","59.96㎡","79.96㎡","2019","20층","12만원","https://land.naver.com/complexes/456","2024-01-15 14:30:01","detail_page"
```

#### 수집 정보 상세
- **complex_name**: 아파트 단지명
- **address**: 주소 정보
- **sale_price**: 매매 가격
- **lease_price**: 전세 가격
- **exclusive_area**: 전용면적
- **supply_area**: 공급면적
- **build_year**: 건축년도
- **floor_info**: 층수 정보
- **maintenance_fee**: 관리비
- **detail_url**: 상세 페이지 URL
- **crawl_date**: 크롤링 일시
- **method**: 수집 방법 (DOM/API/detail_page)

## 구현 세부사항

### 크롤링 전략

#### 1. Selenium WebDriver 사용 이유
- 네이버 부동산은 JavaScript로 동적 렌더링
- Ajax 호출로 데이터 로드
- 정적 HTML 파싱만으로는 데이터 수집 불가

#### 2. Headless 모드 적용
- `--headless` 옵션으로 브라우저 창을 완전히 숨김
- GUI 환경이 없는 서버나 리모트 환경에서 실행 가능
- 메모리 및 CPU 리소스 사용량 최적화
- 백그라운드에서 안정적인 크롤링 수행
- 사용자 인터페이스 없이 자동화 작업에 특화

#### 3. 요소 탐색 전략
```python
# 예상되는 CSS Selector (실제 사이트 구조에 따라 조정 필요)
complexes = driver.find_elements_by_css_selector('.complex_item')
name = complex_elem.find_element_by_css_selector('.complex_title').text
address = complex_elem.find_element_by_css_selector('.complex_address').text
price = complex_elem.find_element_by_css_selector('.complex_price').text
```

#### 4. 지도 데이터 크롤링 전략
네이버 부동산은 지도 상의 데이터를 JavaScript로 동적 로딩하므로 하이브리드 접근 방식을 사용:

##### DOM 크롤링 (기본)
- 브라우저 렌더링 후 HTML 요소 탐색
- 장점: 시각적 확인 가능, 구조 변화에 유연
- 단점: JavaScript 실행 필요, 상대적으로 느림

##### API 크롤링 (폴백)
- 직접 HTTP 요청으로 JSON 데이터 수집
- 엔드포인트: `https://new.land.naver.com/api/complexes/list`
- 파라미터: rletTpCd, tradTpCd, lat, lon, z, btm, top 등
- 장점: 빠름, 안정적, 차단 우회 쉬움

##### 하이브리드 구현
```python
# DOM 크롤링 실패 시 API 자동 전환
try:
    # DOM 기반 크롤링 시도
    complexes = driver.find_elements(By.CSS_SELECTOR, '.complex_item')
except Exception as e:
    print("DOM 크롤링 실패, API 크롤링 시도")
    self.crawl_via_api(params)
```

#### 5. 아파트 상세 정보 수집 전략
복합 단지 목록에서 각 단지를 순회하며 상세 정보를 수집하는 전략:

##### 상세 페이지 탐색
```python
# 새로운 탭에서 상세 페이지 열기
original_window = driver.current_window_handle
driver.execute_script("window.open('');")
driver.switch_to.window(driver.window_handles[-1])

# 상세 페이지 이동 및 정보 추출
driver.get(complex_url)
detail_info = extract_complex_detail_info(complex_name, complex_url)
```

##### 정보 추출 항목
- **주소 정보**: 위치 및 주소 텍스트 추출
- **가격 정보**: 매매/전세/월세 가격
- **면적 정보**: 전용면적, 공급면적
- **건축년월**: 정규식으로 연도 추출
- **층수 정보**: 건물 층수 및 위치
- **관리비**: 월 관리비 정보

##### 다중 탭 관리
```python
# 탭 생성 및 전환
driver.execute_script("window.open('');")
driver.switch_to.window(driver.window_handles[-1])

# 작업 완료 후 정리
driver.close()
driver.switch_to.window(original_window)
```

### 에러 처리 전략

#### 1. 네트워크 오류
- WebDriver 초기화 실패 시 재시도
- 페이지 로딩 타임아웃 처리
- 네트워크 연결 끊김 대응

#### 2. 파싱 오류
- DOM 요소 미존재 시 예외 처리
- 데이터 형식 불일치 대응
- 부분 성공 데이터 저장

#### 3. 시스템 오류
- 메모리 부족 상황 대응
- 파일 쓰기 권한 오류 처리

## 테스트 및 검증

### 단위 테스트 대상
- WebDriver 초기화 기능
- URL 파라미터 생성 로직
- CSV 파일 저장 기능
- 데이터 구조 변환

### 통합 테스트 시나리오
1. 실제 네이버 부동산 URL 접속
2. 데이터 수집 프로세스 전체 실행
3. CSV 파일 생성 및 내용 검증
4. 수집된 데이터의 정확성 확인

### 성능 테스트
- 다양한 크기의 검색 결과 처리
- 메모리 사용량 모니터링
- 실행 시간 측정

## 배포 및 운영

### 실행 환경
```bash
# 의존성 설치 (uv 사용)
uv sync

# 크롤링 실행
uv run python crawler.py
```

### 모니터링 및 로깅
- 콘솔 출력 기반 진행 상황 모니터링
- 에러 발생 시 상세 메시지 출력
- 수집된 데이터 건수 및 처리 시간 표시

### 유지보수 고려사항
- 네이버 사이트 구조 변경 시 CSS Selector 업데이트 필요
- WebDriver 버전 호환성 유지
- Python 및 라이브러리 버전 업그레이드

## 보안 및 법적 고려사항

### 크롤링 정책 준수
- robots.txt 파일 확인 및 준수
- 서비스 이용 약관 준수
- 과도한 요청 빈도 제한

### robots.txt 회피 전략

⚠️ **법적 주의사항**: robots.txt 회피는 서비스 약관 위반 및 법적 리스크를 초래할 수 있습니다. 본 전략은 기술적 연구 목적으로만 제공되며, 실제 사용 시 법적 책임은 사용자에게 있습니다.

#### 1. robots.txt 파싱 무시
- Python의 `urllib.robotparser` 모듈을 사용하지 않음
- robots.txt 파일을 확인하지 않고 직접 크롤링 진행
- Selenium WebDriver는 기본적으로 robots.txt를 확인하지 않음

#### 2. User-Agent 조작
```python
# 일반 브라우저처럼 보이게 User-Agent 설정
options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
```
- robots.txt가 특정 User-Agent에만 적용되는 경우, 허용된 User-Agent로 변경
- 일반 브라우저와 동일한 User-Agent 문자열 사용
- Selenium의 기본 User-Agent를 커스텀 User-Agent로 덮어쓰기

#### 3. robots.txt 규칙 우회
- robots.txt에 명시되지 않은 경로로 접근
- robots.txt가 특정 디렉토리만 차단하는 경우, 다른 경로 활용
- robots.txt의 `Disallow` 규칙에 해당하지 않는 URL 패턴 사용

#### 4. 프록시 및 IP 로테이션
```python
# 프록시 설정 예시
options.add_argument('--proxy-server=http://proxy-server:port')
```
- 여러 IP 주소를 통해 요청 분산
- 각 요청마다 다른 프록시 서버 사용
- IP 차단 우회 및 요청 추적 방지

#### 5. 요청 간격 최소화
- robots.txt의 `Crawl-delay` 지시어 무시
- 최소한의 대기 시간으로 빠른 크롤링 수행
- ⚠️ 주의: 서버 부하를 유발할 수 있으며 IP 차단 위험 증가

#### 6. Selenium 특성 활용
- Selenium은 실제 브라우저를 사용하므로 robots.txt 체크가 덜 엄격할 수 있음
- JavaScript 렌더링을 통한 동적 콘텐츠 접근
- 브라우저 세션 유지로 인한 추가 검증 우회 가능

#### 구현 예시
```python
def setup_driver_with_bypass(self):
    """robots.txt 회피를 위한 WebDriver 설정"""
    options = Options()
    options.add_argument('--headless')
    options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    
    # 프록시 설정 (선택사항)
    # options.add_argument('--proxy-server=http://proxy:port')
    
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
    
    # WebDriver 탐지 방지
    driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
        'source': 'Object.defineProperty(navigator, "webdriver", {get: () => undefined})'
    })
    
    return driver
```

#### 리스크 및 대응 방안
- **IP 차단**: 프록시 로테이션 및 요청 간격 조절
- **계정 정지**: 여러 계정 및 세션 관리
- **법적 조치**: 공식 API 사용 또는 사이트 운영자와 협의 권장

#### 차단 탐지 및 우회 전략

##### 1. 차단 감지 메커니즘
- 네이버 부동산은 다음과 같은 봇 탐지 기법 사용:
  - User-Agent 패턴 분석
  - 요청 빈도 및 패턴 분석
  - JavaScript 실행 여부 확인
  - WebDriver 탐지
  - IP 주소 기반 차단

##### 2. 실시간 차단 대응
```python
# 차단 페이지 감지 및 자동 재시도
def detect_blockage(driver):
    """차단 페이지 감지"""
    try:
        error_element = driver.find_element(By.CSS_SELECTOR, '.tit_error')
        if "서비스 이용이 제한되었습니다" in error_element.text:
            return True
    except:
        pass
    return False

# 재시도 로직
if detect_blockage(self.driver):
    print("🚫 서비스 이용 제한 감지됨")
    if USE_PROXY and PROXY_LIST:
        print("🔄 프록시 변경 후 재시도...")
        # 프록시 로테이션 로직
    else:
        print("⏳ 대기 후 재시도...")
        time.sleep(300)  # 5분 대기
```

##### 3. 고급 우회 기법
- **헤드리스 브라우저 최적화**: `--headless=new` 사용
- **사용자 행동 시뮬레이션**: 스크롤, 클릭, 마우스 이동
- **세션 관리**: 쿠키 및 로컬 스토리지 유지
- **시간 기반 분산**: 피크 타임 피하기
- **멀티 스레드 분산**: 여러 IP에서 동시에 요청하지 않음

##### 4. 모니터링 및 로깅
- 차단 발생 시 자동 알림
- 성공/실패율 통계 수집
- IP별 성능 모니터링

### 데이터 처리
- 개인정보 포함 데이터 수집 금지
- 수집된 데이터의 적절한 사용
- 데이터 보관 및 삭제 정책

### 시스템 보안
- WebDriver 자동 업데이트
- 임시 파일 정리
- 네트워크 요청 로깅 최소화

## 향후 개선 방향

### Phase 2: 고급 기능 추가
- 다중 지역 동시 크롤링
- 데이터베이스 저장 지원
- 스케줄링 기능 (cron)
- API 엔드포인트 제공

### Phase 3: 운영 환경 구축
- Docker 컨테이너화
- 분산 크롤링 아키텍처
- 모니터링 대시보드
- 알림 시스템

## 참고 자료

- 네이버 부동산 서비스: https://new.land.naver.com
- Selenium 문서: https://www.selenium.dev/documentation/
- Python 크롤링 가이드: https://docs.python.org/3/library/

---

**작성일**: 2024년 11월 19일
**버전**: 1.0
**담당자**: 개발팀
