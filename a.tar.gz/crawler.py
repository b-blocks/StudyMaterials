import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import json
import random
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from config import *


class NaverLandCrawler:
    def __init__(self):
        self.base_url = "https://new.land.naver.com/complexes"  # 복합 단지 상세 페이지 URL
        self.complexes_list_url = "https://new.land.naver.com/complexes"  # 복합 단지 목록 URL
        self.data = []
        self.driver = None

    def setup_driver_with_bypass(self):
        """
        강화된 robots.txt 회피를 위한 WebDriver 설정
        네이버 부동산 차단 우회 전략 구현
        """
        options = Options()

        # 기본 설정
        if HEADLESS_MODE:
            options.add_argument('--headless=new')  # 새로운 headless 모드 사용
        options.add_argument(f'--window-size={WINDOW_SIZE}')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-plugins')
        options.add_argument('--disable-images')  # 이미지 로딩 비활성화로 속도 향상
        options.add_argument('--disable-web-security')
        options.add_argument('--allow-running-insecure-content')

        # robots.txt 회피: 고급 User-Agent 및 브라우저 시뮬레이션
        if ENABLE_ROBOTS_BYPASS:
            # 랜덤 User-Agent 선택
            user_agent = random.choice(USER_AGENTS)
            options.add_argument(f'--user-agent={user_agent}')
            print(f"🤖 robots.txt 회피: 고급 User-Agent 설정 - {user_agent}")

            # WebDriver 자동화 감지 방지
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            options.add_experimental_option('useAutomationExtension', False)
            options.add_experimental_option("prefs", {
                "profile.password_manager_enabled": False,
                "credentials_enable_service": False,
            })

            # 추가 옵션들
            options.add_argument('--no-first-run')
            options.add_argument('--no-service-autorun')
            options.add_argument('--password-store=basic')
            options.add_argument('--use-mock-keychain')
            options.add_argument('--disable-ipc-flooding-protection')
            options.add_argument('--disable-popup-blocking')
            options.add_argument('--disable-default-apps')

        # 프록시 설정 (IP 로테이션)
        if USE_PROXY and PROXY_LIST:
            proxy = random.choice(PROXY_LIST)
            options.add_argument(f'--proxy-server={proxy}')
            print(f"🌐 robots.txt 회피: 프록시 설정 - {proxy}")

        try:
            # 최신 Selenium 방식으로 WebDriver 초기화
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=options)

            # 강화된 WebDriver 탐지 방지
            if ENABLE_ROBOTS_BYPASS:
                # CDP 명령어로 navigator.webdriver 제거
                self.driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
                    'source': '''
                        // WebDriver 속성 제거
                        Object.defineProperty(navigator, 'webdriver', {
                            get: () => undefined
                        });

                        // Chrome 자동화 플래그 제거
                        Object.defineProperty(navigator, 'chrome', {
                            get: () => ({
                                runtime: {},
                                loadTimes: function() {},
                                csi: function() {},
                                app: {}
                            })
                        });

                        // 플러그인 시뮬레이션
                        Object.defineProperty(navigator, 'plugins', {
                            get: () => [
                                { name: 'Chrome PDF Plugin', description: 'Portable Document Format', filename: 'internal-pdf-viewer' },
                                { name: 'Chrome PDF Viewer', description: '', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai' },
                                { name: 'Native Client', description: '', filename: 'internal-nacl-plugin' }
                            ]
                        });

                        // 언어 설정
                        Object.defineProperty(navigator, 'languages', {
                            get: () => ['ko-KR', 'ko', 'en-US', 'en']
                        });

                        // 플랫폼 설정
                        Object.defineProperty(navigator, 'platform', {
                            get: () => 'MacIntel'
                        });

                        // 권한 시뮬레이션
                        const originalQuery = window.navigator.permissions.query;
                        window.navigator.permissions.query = (parameters) => (
                            parameters.name === 'notifications' ?
                                Promise.resolve({ state: Notification.permission }) :
                                originalQuery(parameters)
                        );
                    '''
                })

                # 추가 CDP 명령어들
                self.driver.execute_cdp_cmd('Network.enable', {})
                self.driver.execute_cdp_cmd('Page.enable', {})

                # 사용자 행동 시뮬레이션
                time.sleep(1)  # 초기 대기

            print("✅ WebDriver 강화 초기화 완료")
            return True

        except Exception as e:
            print(f"❌ WebDriver 초기화 실패: {e}")
            return False

    def setup_driver(self):
        """기본 WebDriver 설정 (robots.txt 준수)"""
        if ENABLE_ROBOTS_BYPASS:
            return self.setup_driver_with_bypass()
        else:
            # 기본 설정으로 robots.txt 준수
            options = Options()
            if HEADLESS_MODE:
                options.add_argument('--headless')
            options.add_argument(f'--window-size={WINDOW_SIZE}')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')

            try:
                # 최신 Selenium 방식으로 WebDriver 초기화
                service = Service(ChromeDriverManager().install())
                self.driver = webdriver.Chrome(service=service, options=options)
                print("WebDriver 초기화 완료 (robots.txt 준수 모드)")
                return True
            except Exception as e:
                print(f"WebDriver 초기화 실패: {e}")
                return False

    def get_complex_ids(self, params=None):
        """
        특정 지역의 복합 단지 ID 목록을 수집
        /complexes URL에서 복합 단지 링크들을 찾아서 ID 추출
        """
        if params is None:
            params = DEFAULT_PARAMS

        complex_ids = []

        try:
            # 복합 단지 목록 페이지 URL 생성
            url = f"{self.complexes_list_url}?{'&'.join([f'{k}={v}' for k, v in params.items()])}"
            print(f"🔍 복합 단지 목록 수집: {url}")

            # 별도의 WebDriver 세션 사용
            temp_driver = None
            try:
                from selenium import webdriver
                from selenium.webdriver.chrome.options import Options
                from selenium.webdriver.chrome.service import Service
                from webdriver_manager.chrome import ChromeDriverManager

                options = Options()
                if HEADLESS_MODE:
                    options.add_argument('--headless=new')
                options.add_argument(f'--window-size={WINDOW_SIZE}')
                options.add_argument('--no-sandbox')

                service = Service(ChromeDriverManager().install())
                temp_driver = webdriver.Chrome(service=service, options=options)

                temp_driver.get(url)
                time.sleep(PAGE_LOAD_DELAY)

                # 차단 감지 (페이지 소스에서 직접 확인)
                page_source = temp_driver.page_source
                blockage_indicators = [
                    "서비스 이용이 제한되었습니다",
                    "비정상적인 접근이 감지되었습니다",
                    "bot 프로그램",
                    "임시적으로 서비스 이용을 제한"
                ]

                is_blocked = any(indicator in page_source for indicator in blockage_indicators)
                if is_blocked:
                    print("🚫 차단 감지됨")
                    return []

                # 복합 단지 링크들 찾기
                complex_links = temp_driver.find_elements(By.CSS_SELECTOR, 'a[href*="/complexes/"]')

                for link in complex_links[:20]:  # 처음 20개만 처리
                    try:
                        href = link.get_attribute('href')
                        if href and '/complexes/' in href:
                            # URL에서 complex ID 추출 (예: /complexes/369 -> 369)
                            import re
                            match = re.search(r'/complexes/(\d+)', href)
                            if match:
                                complex_id = match.group(1)
                                complex_ids.append(complex_id)
                                print(f"  ✅ 복합 단지 ID 발견: {complex_id}")
                    except:
                        continue

                print(f"🎯 총 {len(complex_ids)}개 복합 단지 ID 수집 완료")
                return complex_ids

            except Exception as e:
                print(f"❌ WebDriver 초기화 또는 페이지 로드 실패: {e}")
                return []
            finally:
                if temp_driver:
                    temp_driver.quit()

        except Exception as e:
            print(f"❌ 복합 단지 ID 수집 오류: {e}")
            return []

    def crawl_articles(self, params=None):
        """
        실제 매물 정보 크롤링 (/complexes/{id} 페이지에서 매물 마커 클릭 → 좌측 상세 정보)
        사용자가 제공한 URL 형태에 맞춰 /complexes/{complex_id} URL 사용
        """
        if params is None:
            params = DEFAULT_PARAMS

        if not self.setup_driver():
            print("WebDriver 초기화 실패로 크롤링을 중단합니다.")
            return

        try:
            # 먼저 해당 지역의 복합 단지 ID 목록 수집
            print("🏢 복합 단지 ID 목록 수집 중...")
            complex_ids = self.get_complex_ids(params)

            if not complex_ids:
                print("❌ 복합 단지 ID를 찾을 수 없습니다.")
                return

            # 각 복합 단지별로 매물 정보 수집
            for complex_id in complex_ids[:5]:  # 테스트를 위해 처음 5개 단지만
                print(f"\n🏗️ 복합 단지 {complex_id} 매물 정보 수집 시작")

                # 복합 단지 상세 페이지 URL 생성 (사용자가 제공한 형태와 동일)
                url = f"{self.base_url}/{complex_id}?{'&'.join([f'{k}={v}' for k, v in params.items()])}"

                print(f"📍 매물 크롤링 URL: {url}")
                self.driver.get(url)

                # JavaScript 렌더링 대기
                print("⏳ 페이지 로딩 대기 중...")
                time.sleep(PAGE_LOAD_DELAY)

                # 차단 방지를 위한 자연스러운 사용자 행동 시뮬레이션
                if ENABLE_ROBOTS_BYPASS:
                    print("🎯 자연스러운 사용자 행동 시뮬레이션...")
                    try:
                        # 페이지 스크롤 (실제 사용자처럼 행동)
                        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight / 4);")
                        time.sleep(SCROLL_DELAY)
                        print("✅ 사용자 행동 시뮬레이션 완료")
                    except Exception as e:
                        print(f"⚠️ 사용자 행동 시뮬레이션 실패 (무시): {e}")

                # 차단 페이지 감지
                if self.detect_blockage():
                    print(f"🚫 복합 단지 {complex_id} 접근 제한됨")
                    continue

                # 매물 마커 요소들 탐색 및 클릭해서 정보 수집
                print("🔍 지도상 매물 마커 탐색 중...")

                # 매물 마커 selector들 (지도상 마커들)
                marker_selectors = [
                    '.marker',  # 기본 마커 클래스
                    '.marker_article',  # 매물 마커
                    '[class*="marker"]',  # 마커 관련 클래스
                    '.cluster',  # 클러스터 마커
                    '.item_marker',  # 마커 아이템
                    'div[role="button"][data-article-no]',  # data 속성으로 매물 구분
                    'img[src*="marker"]',  # 마커 이미지
                    '.pin',  # 핀 모양 마커
                    '.land_marker',  # 부동산 마커
                    '.article_marker'  # 매물 마커
                ]

                # 추가 로딩 대기
                time.sleep(3)

                # 매물 마커들 찾기
                article_markers = []
                found_selector = None

                for selector in marker_selectors:
                    try:
                        elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                        if elements and len(elements) > 0:
                            # 실제 매물 마커인지 검증
                            valid_markers = []
                            for elem in elements[:10]:  # 각 단지당 처음 10개만
                                try:
                                    # 매물 관련 속성 확인
                                    article_no = elem.get_attribute('data-article-no') or elem.get_attribute('article-no')
                                    marker_class = elem.get_attribute('class') or ''
                                    if (article_no or
                                        'article' in marker_class or
                                        'marker' in marker_class or
                                        elem.is_displayed()):  # 보이는 요소만
                                        valid_markers.append(elem)
                                        print(f"  🗺️ 유효한 매물 마커 발견: {article_no or 'N/A'}")
                                except:
                                    continue

                            if len(valid_markers) > 0:
                                article_markers = valid_markers
                                found_selector = selector
                                print(f"✅ 유효한 매물 마커 Selector 발견: {selector} (유효 마커 수: {len(valid_markers)})")
                                break
                    except Exception as e:
                        print(f"  ❌ Selector {selector} 탐색 실패: {e}")
                        continue

                if not article_markers:
                    print(f"❌ 복합 단지 {complex_id}에서 매물 마커를 찾을 수 없습니다.")
                    continue

                print(f"🎯 복합 단지 {complex_id} - 발견된 매물 마커 수: {len(article_markers)}")

                # 각 매물 마커 클릭해서 상세 정보 수집
                for i, marker_elem in enumerate(article_markers[:5]):  # 각 단지당 처음 5개만
                    try:
                        print(f"\n🏠 [{i+1}] 매물 마커 클릭 및 상세 정보 수집 중...")

                        # 매물 마커 클릭
                        try:
                            # 요소가 보이도록 스크롤
                            self.driver.execute_script("arguments[0].scrollIntoView();", marker_elem)
                            time.sleep(0.5)

                            # 마커 클릭
                            marker_elem.click()
                            time.sleep(2)  # 클릭 후 정보 로딩 대기

                            print("  ✅ 매물 마커 클릭 완료")

                        except Exception as e:
                            print(f"  ❌ 매물 마커 클릭 실패: {e}")
                            continue

                        # 클릭 후 좌측 사이드바에서 상세 정보 추출
                        article_info = self.extract_article_detail_info()

                        if article_info:
                            # 복합 단지 ID 추가
                            article_info['complex_id'] = complex_id
                            self.data.append(article_info)
                            print(f"  ✅ 매물 상세 정보 수집 완료: {len(article_info)}개 필드")
                        else:
                            print("  ⚠️ 매물 상세 정보를 추출할 수 없음")

                        # 다음 매물 처리를 위해 약간 대기
                        time.sleep(1)

                    except Exception as e:
                        print(f"❌ 매물 마커 {i+1} 처리 오류: {e}")
                        continue

                print(f"✅ 복합 단지 {complex_id} 매물 크롤링 완료")

            print(f"\n🎉 전체 매물 크롤링 완료: {len(self.data)}개 매물 상세 정보 수집")

        except Exception as e:
            print(f"매물 크롤링 오류: {e}")
            # API 크롤링 시도
            print("🔄 오류로 인해 API 크롤링 시도 중...")
            self.crawl_articles_via_api(params)
            return

        finally:
            if self.driver:
                self.driver.quit()
                print("브라우저 종료")

    def crawl_complexes(self, params=None):
        """
        복합 단지 정보 크롤링
        TECH-SPEC.md의 크롤링 전략 구현
        """
        if params is None:
            params = DEFAULT_PARAMS

        if not self.setup_driver():
            print("WebDriver 초기화 실패로 크롤링을 중단합니다.")
            return

        try:
            # URL 생성
            url = f"{self.base_url}?{'&'.join([f'{k}={v}' for k, v in params.items()])}"

            print(f"크롤링 시작: {url}")
            self.driver.get(url)

            # JavaScript 렌더링 대기 및 자연스러운 행동 시뮬레이션
            print("⏳ 페이지 로딩 대기 중...")
            time.sleep(PAGE_LOAD_DELAY)

            # 차단 방지를 위한 자연스러운 사용자 행동 시뮬레이션
            if ENABLE_ROBOTS_BYPASS:
                print("🎯 자연스러운 사용자 행동 시뮬레이션...")
                try:
                    # 페이지 스크롤 (실제 사용자처럼 행동)
                    self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight / 4);")
                    time.sleep(SCROLL_DELAY)

                    self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight / 2);")
                    time.sleep(SCROLL_DELAY)

                    self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight / 4);")
                    time.sleep(SCROLL_DELAY)

                    # 마우스 움직임 시뮬레이션 (선택사항)
                    from selenium.webdriver.common.action_chains import ActionChains
                    actions = ActionChains(self.driver)
                    actions.move_by_offset(100, 100).perform()
                    time.sleep(0.5)
                    actions.move_by_offset(-50, -50).perform()
                    time.sleep(0.5)

                    print("✅ 사용자 행동 시뮬레이션 완료")

                except Exception as e:
                    print(f"⚠️ 사용자 행동 시뮬레이션 실패 (무시): {e}")
                    pass

            # 차단 페이지 감지
            if self.detect_blockage():
                print("🚫 서비스 이용이 제한되었습니다. 우회 전략 적용 중...")
                return  # 크롤링 중단

            # 데이터 추출 (실제 selector는 사이트 구조에 따라 조정 필요)
            # 페이지 소스 디버깅
            print("📄 페이지 소스 분석 중...")
            page_source = self.driver.page_source

            # 현재 페이지의 주요 요소들 확인
            print("🔍 현재 페이지의 주요 정보:")
            print(f"  URL: {self.driver.current_url}")
            print(f"  Title: {self.driver.title}")
            print(f"  페이지 길이: {len(page_source)} 문자")

            # 지도 데이터나 API 응답 확인
            if 'complexes' in page_source:
                print("✅ 'complexes' 관련 데이터 발견")
            if 'marker' in page_source or '지도' in page_source:
                print("🗺️ 지도 관련 데이터 발견")

            # 실제 DOM 요소 탐색 - 네이버 부동산 복합 단지 목록
            print("🔎 네이버 부동산 복합 단지 목록 탐색 중...")

            # 네이버 부동산 실제 selector 패턴들
            possible_selectors = [
                'a[href*="/complexes/"]',  # 복합 단지 링크
                '.complex_link',  # 복합 단지 링크 클래스
                '[data-complex-no]',  # data 속성
                '.complex_item a',  # 복합 단지 아이템 내 링크
                '.item_complex a',  # 다른 패턴
                '.complex_list a',  # 목록 내 링크
                'div[class*="complex"] a',  # 복합 관련 div 내 링크
                '.cluster a',  # 클러스터 링크
                '.marker a',  # 마커 링크
                'article a',  # article 태그 내 링크
            ]

            # 추가 대기 - 동적 로딩을 위해
            print("⏳ 추가 로딩 대기 중...")
            time.sleep(3)

            # 스크롤을 통해 더 많은 데이터 로드
            print("📜 페이지 스크롤로 추가 데이터 로드...")
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight / 2);")
            time.sleep(2)
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(2)

            complexes = []
            found_selector = None

            for selector in possible_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if elements and len(elements) > 0:
                        # 실제 복합 단지 링크인지 검증
                        valid_elements = []
                        for elem in elements[:10]:  # 처음 10개만 검사
                            try:
                                href = elem.get_attribute('href')
                                text = elem.text.strip()
                                if href and ('/complexes/' in href or 'land.naver.com' in href):
                                    if text and len(text) > 2:  # 의미있는 텍스트가 있는 경우
                                        valid_elements.append(elem)
                                        print(f"  🔗 유효한 복합 단지 링크: {text[:30]}...")
                            except:
                                continue

                        if len(valid_elements) > 0:
                            complexes = valid_elements
                            found_selector = selector
                            print(f"✅ 유효한 복합 단지 Selector 발견: {selector} (유효 요소 수: {len(valid_elements)})")
                            break
                except Exception as e:
                    print(f"  ❌ Selector {selector} 탐색 실패: {e}")
                    continue

            if not complexes:
                print("❌ 복합 단지 요소를 찾을 수 없습니다.")
                print("💡 가능한 해결 방법:")
                print("   1. 페이지가 완전히 로드되지 않았을 수 있음")
                print("   2. JavaScript로 동적 로드되는 데이터일 수 있음")
                print("   3. API를 통해 데이터를 가져와야 할 수 있음")

                # 페이지 소스 저장 (디버깅용)
                with open('debug_page_source.html', 'w', encoding='utf-8') as f:
                    f.write(page_source)
                print("📁 디버그용 페이지 소스 저장: debug_page_source.html")

                # 현재 보이는 모든 텍스트 요소 출력
                text_elements = self.driver.find_elements(By.XPATH, "//*[text()]")
                print(f"📝 페이지 내 텍스트 요소 수: {len(text_elements)}")
                for i, elem in enumerate(text_elements[:10]):  # 처음 10개만
                    text = elem.text.strip()
                    if text and len(text) > 3:  # 의미있는 텍스트만
                        print(f"  {i+1}: {text[:50]}...")

                # DOM 크롤링 실패 시 API 크롤링 시도
                print("🔄 DOM 크롤링 실패, API 크롤링 시도 중...")
                self.crawl_via_api(params)
                return

            print(f"🎯 최종 선택된 selector: {found_selector}")
            print(f"🏢 발견된 복합 단지 수: {len(complexes)}")

            # 각 복합 단지의 상세 정보 수집
            for i, complex_elem in enumerate(complexes[:5]):  # 테스트를 위해 처음 5개만
                try:
                    print(f"\n🏠 [{i+1}] 복합 단지 상세 정보 수집 중...")

                    # 복합 단지 이름과 링크 추출
                    complex_name = complex_elem.text.strip()
                    complex_url = complex_elem.get_attribute('href')

                    if not complex_url:
                        print(f"  ❌ 링크를 찾을 수 없음: {complex_name}")
                        continue

                    print(f"  📍 단지명: {complex_name}")
                    print(f"  🔗 상세 URL: {complex_url}")

                    # 새로운 탭에서 상세 페이지 열기 (기존 페이지 유지)
                    original_window = self.driver.current_window_handle
                    self.driver.execute_script("window.open('');")
                    self.driver.switch_to.window(self.driver.window_handles[-1])

                    try:
                        # 상세 페이지 이동
                        self.driver.get(complex_url)
                        time.sleep(3)  # 페이지 로딩 대기

                        # 차단 페이지 확인
                        if self.detect_blockage():
                            print("  🚫 상세 페이지 접근 제한됨")
                            self.driver.close()
                            self.driver.switch_to.window(original_window)
                            continue

                        # 상세 정보 추출
                        detail_info = self.extract_complex_detail_info(complex_name, complex_url)

                        if detail_info:
                            self.data.append(detail_info)
                            print(f"  ✅ 상세 정보 수집 완료: {len(detail_info)}개 필드")

                    except Exception as e:
                        print(f"  ❌ 상세 페이지 처리 오류: {e}")

                    finally:
                        # 탭 닫고 원래 페이지로 복귀
                        if len(self.driver.window_handles) > 1:
                            self.driver.close()
                        self.driver.switch_to.window(original_window)
                        time.sleep(1)

                except Exception as e:
                    print(f"❌ 복합 단지 {i+1} 처리 오류: {e}")
                    continue

            print(f"\n크롤링 완료: {len(self.data)}개 복합 단지 상세 정보 수집")

        except Exception as e:
            print(f"크롤링 오류: {e}")
            # API 크롤링 시도
            print("🔄 오류로 인해 API 크롤링 시도 중...")
            self.crawl_via_api(params)

        finally:
            if self.driver:
                self.driver.quit()
                print("브라우저 종료")

    def crawl_via_api(self, params=None):
        """
        네이버 부동산 API를 통한 직접 크롤링
        지도 데이터는 JavaScript로 동적 로딩되므로 API가 더 효과적일 수 있음
        """
        if params is None:
            params = DEFAULT_PARAMS

        try:
            # 네이버 부동산 API 엔드포인트 (예상)
            # 실제 엔드포인트는 브라우저 Network 탭에서 확인 필요
            api_urls = [
                "https://new.land.naver.com/api/complexes/list",
                "https://new.land.naver.com/api/regions/list",
                "https://new.land.naver.com/api/articles/list"
            ]

            headers = {
                'User-Agent': random.choice(USER_AGENTS),
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
                'Referer': 'https://new.land.naver.com/',
                'sec-ch-ua': '"Google Chrome";v="120", "Chromium";v="120", "Not-A.Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"macOS"',
            }

            # URL 파라미터 변환 (네이버 API 형식에 맞게)
            api_params = {
                'rletTpCd': params.get('a', 'APT'),  # 부동산 타입
                'tradTpCd': params.get('b', 'A1'),   # 거래 타입
                'z': params.get('ms', '15').split(',')[-1],  # 줌 레벨
                'lat': params.get('ms', '37.530126').split(',')[0],  # 위도
                'lon': params.get('ms', '127.123771').split(',')[1], # 경도
                'btm': params.get('f', '90000'),    # 최소 가격
                'top': params.get('g', '110000'),   # 최대 가격
                'spcMin': params.get('h', '99'),    # 방 수 최소
                'cortarNo': params.get('i', '132'), # 지역 코드
            }

            for api_url in api_urls:
                try:
                    print(f"🔗 API 요청 시도: {api_url}")
                    response = requests.get(
                        api_url,
                        params=api_params,
                        headers=headers,
                        timeout=TIMEOUT
                    )

                    print(f"📡 API 응답 상태: {response.status_code}")

                    if response.status_code == 200:
                        try:
                            data = response.json()
                            print("📋 API 응답 데이터 구조 분석 중...")

                            # 응답 데이터 구조에 따라 파싱
                            if 'complexes' in data:
                                complexes_data = data['complexes']
                            elif 'result' in data and 'list' in data['result']:
                                complexes_data = data['result']['list']
                            elif isinstance(data, list):
                                complexes_data = data
                            else:
                                complexes_data = data

                            print(f"🏢 API에서 받은 데이터 수: {len(complexes_data) if isinstance(complexes_data, list) else 'N/A'}")

                            # 데이터 파싱 및 저장
                            if isinstance(complexes_data, list):
                                for i, complex_data in enumerate(complexes_data):
                                    try:
                                        # API 응답 구조에 따라 필드 매핑
                                        name = complex_data.get('complexName') or complex_data.get('name') or complex_data.get('complex_name', 'N/A')
                                        address = complex_data.get('address') or complex_data.get('addr') or 'N/A'
                                        price = complex_data.get('dealOrWarrantPrc') or complex_data.get('price') or 'N/A'

                                        if isinstance(price, (int, float)):
                                            price = f"{price}만원"

                                        self.data.append({
                                            'name': name,
                                            'address': address,
                                            'price': price,
                                            'crawl_date': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'),
                                            'api_url': api_url,
                                            'robots_bypass': ENABLE_ROBOTS_BYPASS,
                                            'method': 'API'
                                        })

                                        print(f"[{i+1}] {name} - {price}")

                                    except Exception as e:
                                        print(f"API 데이터 {i+1} 파싱 오류: {e}")
                                        continue

                                if self.data:
                                    print(f"✅ API 크롤링 성공: {len(self.data)}개 항목 수집")
                                    return  # 성공했으므로 종료

                        except json.JSONDecodeError:
                            print(f"❌ API 응답이 JSON이 아님: {response.text[:200]}...")
                            continue

                    else:
                        print(f"❌ API 요청 실패: {response.status_code}")
                        continue

                except Exception as e:
                    print(f"API {api_url} 요청 오류: {e}")
                    continue

            if not self.data:
                print("❌ API 크롤링도 실패했습니다.")
                print("💡 해결 방안:")
                print("   1. 브라우저 Network 탭에서 실제 API 엔드포인트 확인")
                print("   2. API 요청 헤더 및 파라미터 조정")
                print("   3. VPN 또는 프록시 사용 고려")

        except Exception as e:
            print(f"API 크롤링 오류: {e}")

    def extract_complex_detail_info(self, complex_name, complex_url):
        """
        복합 단지 상세 페이지에서 정보 추출
        주소, 가격, 평수, 건축년월 등의 아파트 상세 정보 수집
        """
        try:
            detail_info = {
                'complex_name': complex_name,
                'detail_url': complex_url,
                'crawl_date': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'),
                'robots_bypass': ENABLE_ROBOTS_BYPASS,
                'method': 'detail_page'
            }

            # 페이지 소스 분석
            page_source = self.driver.page_source

            # 주소 정보 추출
            address_selectors = [
                '.location',  # 위치 정보
                '.addr',      # 주소
                '[class*="address"]',  # 주소 관련
                '.info_area .txt',  # 정보 영역 텍스트
                'span[class*="location"]'  # 위치 span
            ]

            address = self.extract_text_by_selectors(address_selectors, "주소")
            if address:
                detail_info['address'] = address

            # 건축년월 추출
            build_year_selectors = [
                '.build_year',  # 건축년도
                '[class*="year"]',  # 연도 관련
                '.info dd',  # 상세 정보
                'span:contains("년")',  # '년'이 포함된 텍스트 (CSS selector가 아니라 텍스트 기반)
            ]

            # 건축년월을 텍스트에서 찾기
            build_year_text = self.find_text_containing(page_source, ['년', '년'])
            if build_year_text:
                # 정규식으로 연도 추출 (예: 2020년, 2020.01 등)
                import re
                year_match = re.search(r'(\d{4})년?', build_year_text)
                if year_match:
                    detail_info['build_year'] = year_match.group(1)

            # 가격 정보 추출 (매매, 전세, 월세)
            price_info = self.extract_price_info()
            if price_info:
                detail_info.update(price_info)

            # 평수 정보 추출 (전용면적, 공급면적)
            area_info = self.extract_area_info()
            if area_info:
                detail_info.update(area_info)

            # 추가 정보 추출
            additional_info = self.extract_additional_info()
            if additional_info:
                detail_info.update(additional_info)

            print(f"  📊 추출된 정보: 주소={address}, 건축년도={detail_info.get('build_year', 'N/A')}")
            return detail_info

        except Exception as e:
            print(f"  ❌ 상세 정보 추출 오류: {e}")
            return None

    def extract_text_by_selectors(self, selectors, info_type="정보"):
        """여러 selector를 시도하여 텍스트 추출"""
        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for elem in elements:
                    text = elem.text.strip()
                    if text and len(text) > 3:  # 의미있는 텍스트
                        print(f"  ✅ {info_type} 발견: {text[:50]}...")
                        return text
            except Exception as e:
                continue
        return None

    def find_text_containing(self, page_source, keywords):
        """페이지 소스에서 특정 키워드가 포함된 텍스트 찾기"""
        for keyword in keywords:
            if keyword in page_source:
                # 키워드 주변 텍스트 추출 (간단한 방법)
                start = page_source.find(keyword)
                if start != -1:
                    # 키워드 전후 100자 추출
                    context_start = max(0, start - 50)
                    context_end = min(len(page_source), start + len(keyword) + 50)
                    context = page_source[context_start:context_end]
                    return context
        return None

    def extract_price_info(self):
        """가격 정보 추출 (매매, 전세, 월세)"""
        price_info = {}

        try:
            # 매매 가격
            sale_price_selectors = [
                '.price_sale',  # 매매가
                '[class*="sale"] .price',  # 매매 관련 가격
                '.info_price .sale',  # 가격 정보 내 매매
            ]

            sale_price = self.extract_text_by_selectors(sale_price_selectors, "매매가격")
            if sale_price:
                price_info['sale_price'] = sale_price

            # 전세 가격
            lease_price_selectors = [
                '.price_lease',  # 전세가
                '[class*="lease"] .price',  # 전세 관련 가격
                '.info_price .lease',  # 가격 정보 내 전세
            ]

            lease_price = self.extract_text_by_selectors(lease_price_selectors, "전세가격")
            if lease_price:
                price_info['lease_price'] = lease_price

        except Exception as e:
            print(f"  ⚠️ 가격 정보 추출 오류: {e}")

        return price_info if price_info else None

    def extract_area_info(self):
        """평수/면적 정보 추출"""
        area_info = {}

        try:
            # 전용면적
            exclusive_area_selectors = [
                '.area_exclusive',  # 전용면적
                '[class*="exclusive"]',  # 전용면적 관련
                '.spec_area',  # 면적 스펙
            ]

            exclusive_area = self.extract_text_by_selectors(exclusive_area_selectors, "전용면적")
            if exclusive_area:
                area_info['exclusive_area'] = exclusive_area

            # 공급면적
            supply_area_selectors = [
                '.area_supply',  # 공급면적
                '[class*="supply"]',  # 공급면적 관련
            ]

            supply_area = self.extract_text_by_selectors(supply_area_selectors, "공급면적")
            if supply_area:
                area_info['supply_area'] = supply_area

        except Exception as e:
            print(f"  ⚠️ 면적 정보 추출 오류: {e}")

        return area_info if area_info else None

    def extract_additional_info(self):
        """추가 정보 추출 (층수, 관리비 등)"""
        additional_info = {}

        try:
            # 층수 정보
            floor_selectors = [
                '.floor_info',  # 층수 정보
                '[class*="floor"]',  # 층 관련
            ]

            floor_info = self.extract_text_by_selectors(floor_selectors, "층수정보")
            if floor_info:
                additional_info['floor_info'] = floor_info

            # 관리비
            maintenance_selectors = [
                '.maintenance_fee',  # 관리비
                '[class*="maintenance"]',  # 관리비 관련
                '.fee',  # 요금
            ]

            maintenance_fee = self.extract_text_by_selectors(maintenance_selectors, "관리비")
            if maintenance_fee:
                additional_info['maintenance_fee'] = maintenance_fee

        except Exception as e:
            print(f"  ⚠️ 추가 정보 추출 오류: {e}")

        return additional_info if additional_info else None

    def extract_article_detail_info(self):
        """
        매물 마커 클릭 후 좌측 사이드바에서 상세 정보 추출
        실제 매물의 가격, 위치, 면적 등의 정보 수집
        """
        try:
            detail_info = {
                'crawl_date': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'),
                'robots_bypass': ENABLE_ROBOTS_BYPASS,
                'method': 'article_marker_click'
            }

            # 페이지 소스 분석
            page_source = self.driver.page_source

            # 좌측 사이드바 selector들 (매물 상세 정보 패널)
            sidebar_selectors = [
                '.article_detail',  # 매물 상세 정보
                '.detail_panel',  # 상세 패널
                '.sidebar_detail',  # 사이드바 상세
                '.item_detail',  # 아이템 상세
                '[class*="detail"]',  # 상세 관련 클래스
                '.article_info',  # 매물 정보
                '.property_info',  # 부동산 정보
                'aside',  # 사이드바 태그
                '.aside_detail'  # 사이드바 상세
            ]

            # 매물 타입 및 거래 타입 추출
            trade_type_selectors = [
                '.trade_type',  # 거래 타입
                '[class*="trade"]',  # 거래 관련
                '.deal_type',  # 거래 종류
                '.type_label'  # 타입 라벨
            ]

            trade_type = self.extract_text_by_selectors(trade_type_selectors, "거래타입")
            if trade_type:
                detail_info['trade_type'] = trade_type

            # 가격 정보 추출
            price_selectors = [
                '.price',  # 가격
                '.article_price',  # 매물 가격
                '[class*="price"]',  # 가격 관련
                '.cost',  # 비용
                '.amount'  # 금액
            ]

            price = self.extract_text_by_selectors(price_selectors, "가격")
            if price:
                detail_info['price'] = price

            # 주소 정보 추출
            address_selectors = [
                '.address',  # 주소
                '.location',  # 위치
                '.article_address',  # 매물 주소
                '[class*="address"]',  # 주소 관련
                '.addr',  # 주소 약어
                '.location_info'  # 위치 정보
            ]

            address = self.extract_text_by_selectors(address_selectors, "주소")
            if address:
                detail_info['address'] = address

            # 면적 정보 추출 (전용면적, 공급면적 등)
            area_selectors = [
                '.area',  # 면적
                '.article_area',  # 매물 면적
                '[class*="area"]',  # 면적 관련
                '.space',  # 공간
                '.size'  # 크기
            ]

            area = self.extract_text_by_selectors(area_selectors, "면적")
            if area:
                detail_info['area'] = area

            # 층수 정보 추출
            floor_selectors = [
                '.floor',  # 층수
                '.article_floor',  # 매물 층수
                '[class*="floor"]',  # 층 관련
                '.level'  # 레벨
            ]

            floor = self.extract_text_by_selectors(floor_selectors, "층수")
            if floor:
                detail_info['floor'] = floor

            # 방향 정보 추출
            direction_selectors = [
                '.direction',  # 방향
                '[class*="direction"]',  # 방향 관련
                '.orientation',  # 방향
                '.facing'  # 면한 방향
            ]

            direction = self.extract_text_by_selectors(direction_selectors, "방향")
            if direction:
                detail_info['direction'] = direction

            # 준공년월 추출
            build_year_selectors = [
                '.build_year',  # 준공년도
                '.completion_year',  # 완공년도
                '[class*="year"]',  # 연도 관련
                '.built_year'  # 건축년도
            ]

            build_year = self.extract_text_by_selectors(build_year_selectors, "준공년도")
            if build_year:
                # 숫자만 추출
                import re
                year_match = re.search(r'(\d{4})', build_year)
                if year_match:
                    detail_info['build_year'] = year_match.group(1)

            # 관리비 정보 추출
            maintenance_selectors = [
                '.maintenance',  # 관리비
                '.maintenance_fee',  # 관리비
                '[class*="maintenance"]',  # 관리비 관련
                '.fee',  # 요금
                '.management_cost'  # 관리비용
            ]

            maintenance_fee = self.extract_text_by_selectors(maintenance_selectors, "관리비")
            if maintenance_fee:
                detail_info['maintenance_fee'] = maintenance_fee

            # 추가 정보 추출 (엘리베이터, 주차 등)
            additional_selectors = [
                '.facilities',  # 시설
                '.features',  # 특징
                '.options',  # 옵션
                '[class*="facility"]',  # 시설 관련
                '.amenities'  # 편의시설
            ]

            additional_info = self.extract_text_by_selectors(additional_selectors, "추가정보")
            if additional_info:
                detail_info['additional_info'] = additional_info

            print(f"  📊 추출된 매물 정보: 거래타입={trade_type}, 가격={price}, 주소={address}")

            # 최소한 가격 정보라도 있어야 유효한 데이터로 판단
            if price or address:
                return detail_info
            else:
                return None

        except Exception as e:
            print(f"  ❌ 매물 상세 정보 추출 오류: {e}")
            return None

    def crawl_articles_via_api(self, params=None):
        """
        네이버 부동산 API를 통한 매물 정보 직접 크롤링
        지도 데이터는 JavaScript로 동적 로딩되므로 API가 더 효과적일 수 있음
        """
        if params is None:
            params = DEFAULT_PARAMS

        try:
            # 네이버 부동산 매물 API 엔드포인트
            api_urls = [
                "https://new.land.naver.com/api/articles/list",
                "https://new.land.naver.com/api/articles",
                "https://new.land.naver.com/api/search/articles"
            ]

            headers = {
                'User-Agent': random.choice(USER_AGENTS),
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
                'Referer': 'https://new.land.naver.com/',
                'sec-ch-ua': '"Google Chrome";v="120", "Chromium";v="120", "Not-A.Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"macOS"',
            }

            # URL 파라미터 변환 (네이버 API 형식에 맞게)
            api_params = {
                'rletTpCd': params.get('a', 'APT'),  # 부동산 타입
                'tradTpCd': params.get('b', 'A1'),   # 거래 타입
                'z': params.get('ms', '15').split(',')[-1],  # 줌 레벨
                'lat': params.get('ms', '37.530126').split(',')[0],  # 위도
                'lon': params.get('ms', '127.123771').split(',')[1], # 경도
                'btm': params.get('f', '90000'),    # 최소 가격
                'top': params.get('g', '110000'),   # 최대 가격
                'spcMin': params.get('h', '99'),    # 방 수 최소
                'cortarNo': params.get('i', '132'), # 지역 코드
                'page': '1',  # 페이지 번호
                'size': '20'  # 페이지당 항목 수
            }

            for api_url in api_urls:
                try:
                    print(f"🔗 매물 API 요청 시도: {api_url}")
                    response = requests.get(
                        api_url,
                        params=api_params,
                        headers=headers,
                        timeout=TIMEOUT
                    )

                    print(f"📡 매물 API 응답 상태: {response.status_code}")

                    if response.status_code == 200:
                        try:
                            data = response.json()
                            print("📋 매물 API 응답 데이터 구조 분석 중...")

                            # 응답 데이터 구조에 따라 파싱
                            if 'articles' in data:
                                articles_data = data['articles']
                            elif 'result' in data and 'list' in data['result']:
                                articles_data = data['result']['list']
                            elif 'body' in data and 'articles' in data['body']:
                                articles_data = data['body']['articles']
                            elif isinstance(data, list):
                                articles_data = data
                            else:
                                articles_data = data

                            print(f"🏠 API에서 받은 매물 데이터 수: {len(articles_data) if isinstance(articles_data, list) else 'N/A'}")

                            # 데이터 파싱 및 저장
                            if isinstance(articles_data, list):
                                for i, article_data in enumerate(articles_data):
                                    try:
                                        # API 응답 구조에 따라 필드 매핑
                                        trade_type = article_data.get('tradTpNm') or article_data.get('tradeType') or 'N/A'  # 거래 타입
                                        price = article_data.get('prc') or article_data.get('price') or 'N/A'  # 가격
                                        address = article_data.get('addr') or article_data.get('address') or 'N/A'  # 주소
                                        area = article_data.get('spc1') or article_data.get('area') or 'N/A'  # 면적
                                        floor = article_data.get('flrInfo') or article_data.get('floor') or 'N/A'  # 층수
                                        direction = article_data.get('direction') or article_data.get('dir') or 'N/A'  # 방향
                                        build_year = article_data.get('buildYear') or article_data.get('year') or 'N/A'  # 준공년도

                                        # 가격 포맷팅
                                        if isinstance(price, (int, float)):
                                            price = f"{price}만원"

                                        self.data.append({
                                            'trade_type': trade_type,
                                            'price': price,
                                            'address': address,
                                            'area': area,
                                            'floor': floor,
                                            'direction': direction,
                                            'build_year': build_year,
                                            'crawl_date': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'),
                                            'api_url': api_url,
                                            'robots_bypass': ENABLE_ROBOTS_BYPASS,
                                            'method': 'articles_api'
                                        })

                                        print(f"[{i+1}] {trade_type} - {price} - {address}")

                                    except Exception as e:
                                        print(f"매물 API 데이터 {i+1} 파싱 오류: {e}")
                                        continue

                                if self.data:
                                    print(f"✅ 매물 API 크롤링 성공: {len(self.data)}개 항목 수집")
                                    return  # 성공했으므로 종료

                        except json.JSONDecodeError:
                            print(f"❌ 매물 API 응답이 JSON이 아님: {response.text[:200]}...")
                            continue

                    else:
                        print(f"❌ 매물 API 요청 실패: {response.status_code}")
                        continue

                except Exception as e:
                    print(f"매물 API {api_url} 요청 오류: {e}")
                    continue

            if not self.data:
                print("❌ 매물 API 크롤링도 실패했습니다.")
                print("💡 해결 방안:")
                print("   1. 브라우저 Network 탭에서 실제 매물 API 엔드포인트 확인")
                print("   2. API 요청 헤더 및 파라미터 조정")
                print("   3. VPN 또는 프록시 사용 고려")

        except Exception as e:
            print(f"매물 API 크롤링 오류: {e}")

    def save_to_csv(self, filename=None):
        """데이터를 CSV 파일로 저장"""
        if filename is None:
            filename = CSV_FILENAME

        # 출력 디렉토리 생성
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        filepath = os.path.join(OUTPUT_DIR, filename)

        if self.data:
            df = pd.DataFrame(self.data)
            df.to_csv(filepath, index=False, encoding='utf-8-sig')
            print(f"데이터 저장 완료: {filepath} ({len(self.data)}개 항목)")
            return True
        else:
            print("저장할 데이터가 없습니다.")
            return False

    def detect_blockage(self):
        """차단 페이지 감지 (TECH-SPEC.md: 실시간 차단 대응)"""
        try:
            # 차단 페이지의 주요 특징 감지
            page_source = self.driver.page_source

            # 차단 메시지 감지
            blockage_indicators = [
                "서비스 이용이 제한되었습니다",
                "비정상적인 접근이 감지되었습니다",
                "bot 프로그램",
                "임시적으로 서비스 이용을 제한",
                ".tit_error",
                ".p_error"
            ]

            for indicator in blockage_indicators:
                if indicator in page_source:
                    print(f"🚨 차단 감지됨: '{indicator}'")
                    return True

            # URL 변경 감지 (리다이렉트)
            current_url = self.driver.current_url
            if "error" in current_url.lower() or "block" in current_url.lower():
                print(f"🚨 차단 URL 감지됨: {current_url}")
                return True

            return False

        except Exception as e:
            print(f"차단 감지 중 오류: {e}")
            return False

    def check_robots_txt(self):
        """robots.txt 파일 확인 (준수 모드용)"""
        try:
            robots_url = "https://new.land.naver.com/robots.txt"
            response = requests.get(robots_url, timeout=10)

            if response.status_code == 200:
                print("robots.txt 내용:")
                print(response.text)
                return response.text
            else:
                print(f"robots.txt 확인 실패: HTTP {response.status_code}")
                return None
        except Exception as e:
            print(f"robots.txt 확인 오류: {e}")
            return None


def main():
    """메인 실행 함수"""
    print("🚀 네이버 부동산 크롤링 시작")
    print("=" * 50)
    print(f"🤖 robots.txt 회피 모드: {'활성화' if ENABLE_ROBOTS_BYPASS else '비활성화'}")
    print(f"🌐 프록시 사용: {'활성화' if USE_PROXY else '비활성화'}")
    print(f"👁️  Headless 모드: {'활성화' if HEADLESS_MODE else '비활성화'}")
    print("=" * 50)

    # robots.txt 확인 (준수 모드일 때)
    if not ENABLE_ROBOTS_BYPASS:
        print("\n=== robots.txt 준수 모드 ===")
        crawler = NaverLandCrawler()
        robots_content = crawler.check_robots_txt()
        if robots_content and 'Disallow' in robots_content:
            print("⚠️ robots.txt에 제한 규칙이 있습니다. 크롤링을 진행하시겠습니까?")
    else:
        print("\n=== robots.txt 회피 모드 ===")
        print("⚠️ 법적 주의사항: robots.txt 회피는 서비스 약관 위반의 위험이 있습니다.")
        print("💡 대안: 네이버 부동산 API 또는 공식 데이터 수집 방법을 고려하세요.")

        if not USE_PROXY:
            print("\n💡 프록시 사용 추천:")
            print("   config.py에서 USE_PROXY = True로 설정하고")
            print("   PROXY_LIST에 프록시 서버를 추가하세요.")

    # 크롤링 실행
    try:
        crawler = NaverLandCrawler()

        # 여러 지역의 실제 매물 정보 크롤링
        for loc in TARGET_LOCATIONS:
            print(f"\n📍 지역 매물 크롤링 시작: 위도 {loc['lat']}, 경도 {loc['lon']}")

            # 파라미터 업데이트
            params = DEFAULT_PARAMS.copy()
            params['ms'] = f"{loc['lat']},{loc['lon']},15"
            params['i'] = loc['cortarNo']

            crawler.crawl_articles(params)

            # 지역 간 대기 시간 (차단 방지)
            time.sleep(3)

        success = crawler.save_to_csv()

        if success:
            print("\n✅ 매물 크롤링 작업 완료!")
            print(f"📁 결과 파일: {os.path.join(OUTPUT_DIR, CSV_FILENAME)}")
            print("📊 수집된 정보: 거래타입, 가격, 주소, 면적, 층수, 방향, 준공년도 등")
        else:
            print("\n❌ 크롤링 작업 실패 (데이터 없음)")

    except KeyboardInterrupt:
        print("\n⏹️  사용자가 크롤링을 중단했습니다.")
    except Exception as e:
        print(f"\n❌ 크롤링 중 오류 발생: {e}")

    print("\n" + "=" * 50)
    print("크롤링 프로그램 종료")
    print("=" * 50)


if __name__ == "__main__":
    main()
