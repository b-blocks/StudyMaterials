URL 이것은 강동구 기준이다. 
https://new.land.naver.com/complexes?ms=37.530126,127.123771,15&a=APT&b=A1&e=RETAIL&f=90000&g=110000&h=99&i=132

프로젝트 루트에 다음 파일들을 생성하세요:
1. requirements.txt
1
requests==2.31.0beautifulsoup4==4.12.2pandas==2.1.3selenium==4.15.2webdriver-manager==4.0.1
2. crawler.py (메인 크롤링 스크립트)
crawler.py
Apply to crawler.py
import requestsfrom bs4 import BeautifulSoupimport pandas as pdimport timeimport jsonfrom selenium import webdriverfrom selenium.webdriver.chrome.options import Optionsfrom webdriver_manager.chrome import ChromeDriverManagerclass NaverLandCrawler:    def __init__(self):        self.base_url = "https://new.land.naver.com/complexes"        self.data = []            def setup_driver(self):        """Selenium 드라이버 설정"""        options = Options()        options.add_argument('--headless')  # 브라우저 창 숨기기        options.add_argument('--no-sandbox')        options.add_argument('--disable-dev-shm-usage')                driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)        return driver        def crawl_complexes(self, params=None):        """복합 단지 정보 크롤링"""        if params is None:            # README.md의 URL 파라미터 사용            params = {                'ms': '37.530126,127.123771,15',                'a': 'APT',                'b': 'A1',                'e': 'RETAIL',                'f': '90000',                'g': '110000',                'h': '99',                'i': '132'            }                try:            # Selenium을 사용한 크롤링 (JavaScript 렌더링 필요)            driver = self.setup_driver()            url = f"{self.base_url}?{'&'.join([f'{k}={v}' for k, v in params.items()])}"                        print(f"크롤링 시작: {url}")            driver.get(url)                        # 페이지 로딩 대기            time.sleep(3)                        # 데이터 추출 (실제 selector는 사이트 구조에 따라 조정 필요)            complexes = driver.find_elements_by_css_selector('.complex_item')                        for complex_elem in complexes:                try:                    name = complex_elem.find_element_by_css_selector('.complex_title').text                    address = complex_elem.find_element_by_css_selector('.complex_address').text                    price = complex_elem.find_element_by_css_selector('.complex_price').text                                        self.data.append({                        'name': name,                        'address': address,                        'price': price,                        'crawl_date': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')                    })                                    except Exception as e:                    print(f"항목 파싱 오류: {e}")                    continue                        driver.quit()            print(f"크롤링 완료: {len(self.data)}개 항목 수집")                    except Exception as e:            print(f"크롤링 오류: {e}")        def save_to_csv(self, filename='naver_land_data.csv'):        """데이터를 CSV 파일로 저장"""        if self.data:            df = pd.DataFrame(self.data)            df.to_csv(filename, index=False, encoding='utf-8-sig')            print(f"데이터 저장 완료: {filename}")        else:            print("저장할 데이터가 없습니다.")def main():    crawler = NaverLandCrawler()    crawler.crawl_complexes()    crawler.save_to_csv()if __name__ == "__main__":    main()
3. config.py (설정 파일)
config.py
Apply to config.py
# 크롤링 설정CRAWL_DELAY = 1  # 요청 간격 (초)MAX_RETRIES = 3   # 최대 재시도 횟수TIMEOUT = 30      # 요청 타임아웃 (초)# 출력 설정OUTPUT_DIR = 'output'CSV_FILENAME = 'naver_land_data.csv'# 대상 URL 파라미터DEFAULT_PARAMS = {    'ms': '37.530126,127.123771,15',  # 지도 중심 좌표 및 줌 레벨    'a': 'APT',                        # 아파트    'b': 'A1',                         # 매매    'e': 'RETAIL',                     # 상가    'f': '90000',                      # 최소 가격    'g': '110000',                     # 최대 가격    'h': '99',                         # 방 수 (99=전체)    'i': '132'                         # 지역 코드}
4. 간단한 실행 방법
터미널에서 다음 명령어로 실행:
# 의존성 설치 (uv 사용)
uv sync

# 크롤링 실행
uv run python crawler.py
주의사항

## ⚖️ 법적 고려사항
- 네이버의 robots.txt를 확인하고, 서비스 약관을 준수하세요
- 과도한 요청은 IP 차단될 수 있습니다
- **차단 당한 경우**: robots.txt 회피 기능이 자동으로 활성화됩니다

## 🔧 기술적 고려사항
- 네이버 부동산은 JavaScript로 렌더링되므로 Selenium 사용
- 실제 데이터 selector는 사이트 변경에 따라 조정 필요
- 크롤링 간격을 두어 서버 부하를 줄이세요

## 🚫 차단 대응 방법

### 방법 1: 프록시 사용 (권장)
```bash
# config.py에서 설정
USE_PROXY = True
PROXY_LIST = [
    "http://your-proxy-server:port",
    "http://another-proxy:port"
]
```

### 방법 2: VPN 사용
- VPN 서비스를 통해 IP 변경
- 상용 VPN (NordVPN, ExpressVPN 등) 사용

### 방법 3: API 대안
네이버 부동산 공식 API 사용을 고려하세요:
- 네이버 개발자 센터 확인
- 공식 데이터 제공 서비스 활용

### 방법 4: 요청 간격 증가
```python
# config.py에서 조정
CRAWL_DELAY = 10  # 10초로 증가
PAGE_LOAD_DELAY = 8  # 페이지 로딩 대기 증가
```

### 방법 5: API 직접 크롤링
네이버 부동산은 지도 데이터를 JavaScript로 로드하므로 API를 직접 호출하는 것이 효과적일 수 있습니다.

**실제 API 엔드포인트 찾는 방법:**
1. Chrome에서 F12 → Network 탭 열기
2. 네이버 부동산 접속
3. XHR/Fetch 필터 선택
4. 지도나 검색 시도
5. `api/`로 시작하는 요청들 확인

**일반적인 API 엔드포인트:**
- `https://new.land.naver.com/api/complexes/list`
- `https://new.land.naver.com/api/articles/list`

## 🔄 재시도 방법
차단 해제까지 기다린 후 다시 시도:
```bash
# 캐시 정리 후 재시도
uv cache clean
rm -rf .venv
uv sync
uv run python crawler.py
```

## 🗺️ 지도 데이터 크롤링

네이버 부동산의 지도 상 데이터는 다음과 같은 방법으로 수집 가능:

### 1. **DOM 크롤링 (현재 기본 방식)**
- 브라우저 렌더링 후 HTML 요소 파싱
- 장점: 직관적, 시각적 확인 가능
- 단점: JavaScript 의존, 느림

### 2. **API 크롤링 (자동 폴백)**
- 직접 HTTP 요청으로 JSON 데이터 수집
- 장점: 빠름, 안정적, 차단 우회 쉬움
- 단점: API 엔드포인트 변경 시 수정 필요

### 3. **하이브리드 방식 (권장)**
- DOM 크롤링 실패 시 API 크롤링 자동 전환
- 현재 구현된 방식

## 🏠 아파트 상세 정보 수집

크롤러는 자동으로 다음 정보를 수집합니다:

### 수집 정보
- ✅ **단지명**: 아파트 단지 이름
- ✅ **주소**: 정확한 위치 정보
- ✅ **매매가격**: 현재 매매 시세
- ✅ **전세가격**: 전세 시세 정보
- ✅ **전용면적**: 실사용 면적
- ✅ **공급면적**: 총 면적
- ✅ **건축년도**: 준공 연도
- ✅ **층수정보**: 건물 층수
- ✅ **관리비**: 월 관리비

### 수집 방식
1. **검색 결과 페이지**에서 복합 단지 목록 탐색
2. **각 단지 클릭**하여 상세 페이지로 이동
3. **상세 정보 추출** 후 다음 단지로 진행
4. **다중 탭 관리**로 효율적인 크롤링

## 📊 개선 방향
- 프록시 로테이션 추가
- 데이터베이스 저장
- API 엔드포인트 자동 탐색
- 분산 크롤링 구현
- 실시간 시세 모니터링
- 가격 변동 알림 기능


