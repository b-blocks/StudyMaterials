# 크롤링 설정
CRAWL_DELAY = 3  # 요청 간격 (초) - 차단 방지를 위해 증가
MAX_RETRIES = 3   # 최대 재시도 횟수
TIMEOUT = 30      # 요청 타임아웃 (초)
PAGE_LOAD_DELAY = 5  # 페이지 로딩 후 대기 시간 (초)
SCROLL_DELAY = 2     # 스크롤 간격 (초)

# 출력 설정
OUTPUT_DIR = 'output'
CSV_FILENAME = 'naver_articles_data.csv'  # 매물 정보 파일명

# robots.txt 회피 설정
ENABLE_ROBOTS_BYPASS = True   # robots.txt 회피 활성화 여부
USE_PROXY = False             # 프록시 사용 여부 (True로 설정 시 프록시 사용)
PROXY_LIST = [
    # 프록시 서버 목록 (필요시 추가)
    # "http://proxy1:port",
    # "http://proxy2:port",
]

# WebDriver 설정
HEADLESS_MODE = True          # Headless 모드 사용
WINDOW_SIZE = '1920,1080'     # 브라우저 창 크기

# 대상 URL 파라미터
DEFAULT_PARAMS = {
    'ms': '37.530126,127.123771,15',   # 지도 중심 좌표 및 줌 레벨
    'a': 'APT:PRE',                    # 부동산 타입 (아파트:분양권)
    'b': 'A1',                         # 거래 타입 (매매)
    'e': 'RETAIL',                     # 추가 타입 (상가)
    'f': '90000',                      # 최소 가격 (만원)
    'g': '110000',                     # 최대 가격 (만원)
    'h': '99',                         # 방 수 (99=전체)
    'i': '132'                         # 지역 코드 (강동구)
}

# 크롤링할 좌표 목록 (위도, 경도, 지역코드)
# 실제 매물이 있는 주요 지역 좌표
TARGET_LOCATIONS = [
    {'lat': '37.513261', 'lon': '127.100133', 'cortarNo': '1171010100'},
    {'lat': '37.497952', 'lon': '127.027619', 'cortarNo': '1168010600'},  # 강남구 역삼동 (강남역)
    {'lat': '37.513261', 'lon': '127.100133', 'cortarNo': '1171010100'},  # 송파구 잠실동 (잠실역)
    {'lat': '37.521941', 'lon': '126.924345', 'cortarNo': '1156011000'},  # 영등포구 여의도동
    {'lat': '37.566535', 'lon': '126.977969', 'cortarNo': '1114010300'},  # 중구 태평로1가 (시청)
    {'lat': '37.530126', 'lon': '127.123771', 'cortarNo': '1174010900'},  # 강동구 천호동
]

# CSS Selector 설정 (실제 사이트 구조에 따라 조정 필요)
SELECTORS = {
    'complex_item': '.complex_item',
    'complex_title': '.complex_title',
    'complex_address': '.complex_address',
    'complex_price': '.complex_price'
}

# User-Agent 설정 (robots.txt 회피용)
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0'
]
